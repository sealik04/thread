import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Fight obj = new Fight();
        Scanner sc = new Scanner(System.in);
        System.out.println("name your fighters: \n");
        System.out.println("first: \n");
        String name1 = sc.nextLine();
        System.out.println("second \n");
        String name2 = sc.nextLine();

        ThreadOne to = new ThreadOne(name1, obj);
        ThreadTwo tt = new ThreadTwo(name2, obj);
    }
}