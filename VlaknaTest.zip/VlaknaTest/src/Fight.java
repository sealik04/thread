public class Fight {
    String fName;
    int fStrength;
    int fHitPoints;

    public synchronized void Hit(String name, int strength, int hitPoints){
        fName = name;
        fStrength = strength;
        fHitPoints = hitPoints;

        TakeHit(fName, fStrength, fHitPoints);
        System.out.println(fHitPoints);
        try {
            Thread.sleep(100);
        } catch (InterruptedException ex){
            System.out.println("L");
        }
        notifyAll();
    }

    public synchronized void TakeHit(String jmeno, int sila, int zivoty){
        fName = jmeno;
        fStrength = sila;
        fHitPoints = zivoty;

        fHitPoints -= fStrength;
        System.out.println(fHitPoints);
        try {
            Thread.sleep(100);
        } catch (InterruptedException ex){
            System.out.println("L");
        }
        notifyAll();
    }
}
