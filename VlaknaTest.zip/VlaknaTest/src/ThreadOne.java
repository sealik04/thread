public class ThreadOne implements Runnable{
    Fight obj;
    String name;
    int strength = 4;
    int hitPoints = 100;
    public ThreadOne(String jmeno, Fight ob){
        name = jmeno;
        obj = ob;
    }

    @Override
    public void run() {
        while(hitPoints > 0) {
            obj.TakeHit(name, strength, hitPoints);
        }
    }
}
