public class ThreadTwo implements Runnable{
    Fight obj;
    String name;
    int strength = 5;
    int hitPoints = 100;
    public ThreadTwo(String jmeno, Fight ob){
        name = jmeno;
        obj = ob;
    }

    @Override
    public void run() {
        while(hitPoints > 0) {
            obj.Hit(name, strength, hitPoints);
        }
    }
}
